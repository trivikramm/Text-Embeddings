import React from 'react';

export default function UserForm() {
  return (
    <form>
      {/* Name Field */}
      <label>Name: <input type="text" name="name" /></label><br />
      {/* Email Field */}
      <label>Email: <input type="email" name="email" /></label><br />
      {/* Date Field */}
      <label>Date: <input type="date" name="date" /></label><br />
      {/* Gender Field */}
      <label>Gender:
        <select name="gender">
          <option value="">Select</option>
          <option value="male">Male</option>
          <option value="female">Female</option>
        </select>
      </label><br />
      {/* Account Type */}
      <label>Account Type:
        <input type="radio" name="accountType" value="savings" /> Savings
        <input type="radio" name="accountType" value="current" /> Current
      </label><br />
      {/* Agree Checkbox */}
      <label>
        <input type="checkbox" name="agree" /> I agree to terms and conditions
      </label><br />
      {/* Submit Button */}
      <button type="submit">Submit</button>
    </form>
  );
}
