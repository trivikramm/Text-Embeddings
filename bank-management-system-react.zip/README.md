# Bank Management System (React Version)

> React form project setup for testing environment.