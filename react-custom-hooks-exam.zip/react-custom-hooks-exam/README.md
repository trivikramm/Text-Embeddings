
# React Custom Hooks Exam-Style Project

This project contains custom hook problems like an exam platform. You are supposed to write the correct implementation so that test cases in `App.test.js` pass.

## Problems

1. `useToggle` - toggle a boolean value.
2. `useFetch` - fetch data from an API URL.
3. `useLocalStorage` - store and retrieve value from localStorage.

Run `npm install` and then `npm test` to validate your answers.
