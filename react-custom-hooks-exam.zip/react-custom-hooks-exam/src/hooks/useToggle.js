
// ❓ Problem: Create a custom hook `useToggle`
// - Initializes with a boolean (default: false)
// - Returns the boolean and a function to toggle it

import { useState } from "react";

export function useToggle(initialValue = false) {
  const [value, setValue] = useState(initialValue);
  const toggle = () => setValue((prev) => !prev);
  return [value, toggle];
}
