
import { renderHook, act } from "@testing-library/react-hooks";
import { useToggle } from "../hooks/useToggle";
import { useLocalStorage } from "../hooks/useLocalStorage";

describe("useToggle", () => {
  it("should toggle value correctly", () => {
    const { result } = renderHook(() => useToggle());
    expect(result.current[0]).toBe(false);
    act(() => result.current[1]());
    expect(result.current[0]).toBe(true);
    act(() => result.current[1]());
    expect(result.current[0]).toBe(false);
  });
});

describe("useLocalStorage", () => {
  beforeEach(() => localStorage.clear());

  it("should store initial value", () => {
    const { result } = renderHook(() => useLocalStorage("testKey", "initial"));
    expect(result.current[0]).toBe("initial");
  });

  it("should update and persist value", () => {
    const { result } = renderHook(() => useLocalStorage("testKey", "initial"));
    act(() => result.current[1]("updated"));
    expect(localStorage.getItem("testKey")).toBe(JSON.stringify("updated"));
  });
});
