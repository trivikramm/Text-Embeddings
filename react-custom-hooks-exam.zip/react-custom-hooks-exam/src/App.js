
import React from "react";

function App() {
  return <h2>React Custom Hook Problems Platform</h2>;
}

export default App;
